function W = projectLinf1BlockFast(W,nIndices,lambda)

projectBlockL1(W,nIndices,lambda); % MEX file works in-place!

