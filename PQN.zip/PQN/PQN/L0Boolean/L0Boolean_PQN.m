clc
clear

% % Generate Syntehtic Data
% nInstances = 200;
% nVars = 1000;
% k = 20;
% pho=0.2;
% SNR = 6;
% T = toeplitz(pho.^(1:nVars));
% RandIndtmp = randperm(nVars);
% RandInd = sort(RandIndtmp(1:k));
% RandInt = 2*randi([0,1],k,1)-1;
% X =  mvnrnd(zeros(1,nVars), T, nInstances);
% w = zeros(nVars,1);
% w(RandInd) = RandInt;%rand(nVars,1).*(rand(nVars,1) > .5);
% utrue = w;% Set up Simplex Projection Function
% 
% utrue(RandInd) = 1.0;
% NoiseT = normrnd(0,1,nInstances,1);
% Noise = ((norm(X*w)/sqrt(SNR))/norm(NoiseT))*NoiseT;
% y = X*w + Noise;
% pho = 2;

load Xnd.txt
load yn.txt
load wd.txt
X = Xnd;
[nInstances, nVars] = size(X);
y = yn;
w = wd;
[rid, cid] = find(wd);
utrue = w;
utrue(rid,1) = 1.;
k=20;
pho = 2;



% Initial guess of parameters
uSimplex = zeros(nVars,1);

% Set up Objective Function
funObj = @(w)L0Obj(w,X,y,pho);

% Set up Simplex Projection Function
funProj = @(w)ProjCSimplex(w,k);

% Solve with PQN
options.maxIter = 100;
[uout, err, obj] = minConF_PQN_V2(funObj,uSimplex,funProj,utrue,options);

[B, Ranktmp] = sort(-uout);
Rank = sort(Ranktmp(1:k))
uout(Rank)
