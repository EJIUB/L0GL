function [f,g] = L0Obj(u,X,y,pho)
%u(feature,1)
%X(instance, feature)
%y(instance,1)
%pho(1,1)

[n,d] = size(X);
M = inv((1/pho)*X*diag(u)*X'+eye(n));
f = y'*M*y;

g=-(1/pho)*((X'*M*y).^2);





