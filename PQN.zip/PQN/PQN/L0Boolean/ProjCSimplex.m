function [up] = ProjCSimplex(u,k)

[n,m] = size(u);

H = 0.5*eye(n);
f = -0.5*u;
A = ones(1,n);
b = k;

lb = zeros(n,1);
ub = ones(n,1);

options = optimoptions('quadprog','Display','off');
up = quadprog(H,f,A,b,[],[],lb,ub,[],options);
