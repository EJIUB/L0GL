PQNexp_CRF(1,1,8936,19);
PQNexp_GGM(1,.1,50);
PQNexp_GrGGM(1,.1,50);
PQNexp_MRF(1,5400,10,50,'exact');
PQNexp_GrGGM2(1,50);