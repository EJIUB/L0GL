function t = traceMatProd(A,B)
% Compute trace(A*B)

t = sum(sum(A.*B'));
